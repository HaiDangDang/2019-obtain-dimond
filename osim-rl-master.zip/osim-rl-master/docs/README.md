You can run jekyll locally:
```
gem install bundler jekyll
git clone https://github.com/stanfordnmbl/osim-rl.git
cd osim-rl/docs
bundle install
bundle exec jekyll serve
```
